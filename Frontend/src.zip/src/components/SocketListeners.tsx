import { useEffect } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { useSocket } from '../contexts/SocketContext';
import { useNotifications } from '../components/NotificationContext';
import { toast } from 'react-toastify';

export function SocketListeners() {
  const { socket, on, off, isConnected } = useSocket();
  const queryClient = useQueryClient();
  const { addNotification } = useNotifications();

  useEffect(() => {
    const playProductionAlert = () => {
      // A generated tone avoids bundling an arbitrary audio asset. Browsers
      // may require a prior user interaction before allowing audio playback.
      try {
        const AudioContextCtor = window.AudioContext || (window as any).webkitAudioContext;
        const context = new AudioContextCtor();
        const oscillator = context.createOscillator();
        const gain = context.createGain();
        oscillator.frequency.value = 880;
        gain.gain.setValueAtTime(0.12, context.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, context.currentTime + 0.45);
        oscillator.connect(gain).connect(context.destination);
        oscillator.start();
        oscillator.stop(context.currentTime + 0.45);
      } catch {
        // Notification remains visible when the device/browser disallows sound.
      }
    };
    const handleNovoPedido = (payload: any) => {
      queryClient.invalidateQueries({ queryKey: ['pedidos'] });
      queryClient.invalidateQueries({ queryKey: ['requests'] });
      const msg = payload?.numero ? `Novo pedido recebido: ${payload.numero}` : 'Novo pedido recebido!';
      toast.info(msg);
      addNotification({ title: 'Novo Pedido', message: msg, type: 'info' });
    };

    const handleNovaOrdemProducao = (payload: any) => {
      queryClient.invalidateQueries({ queryKey: ['producao'] });
      queryClient.invalidateQueries({ queryKey: ['production-orders'] });
      queryClient.invalidateQueries({ queryKey: ['prod-cal'] });
      queryClient.invalidateQueries({ queryKey: ['calendario-dia'] });
      queryClient.invalidateQueries({ queryKey: ['pedidos'] });
      queryClient.invalidateQueries({ queryKey: ['requests'] });
      const sector = payload?.sector || 'Produção';
      const msg = payload?.numero ? `Nova ordem de produção em ${sector}: ${payload.numero}` : `Tlim! Nova ordem recebida em ${sector}!`;
      playProductionAlert();
      toast.success(msg);
      addNotification({ title: sector, message: msg, type: 'success' });
    };

    const handleProducaoIniciada = (payload: any) => {
      queryClient.invalidateQueries({ queryKey: ['producao'] });
      queryClient.invalidateQueries({ queryKey: ['production-orders'] });
      queryClient.invalidateQueries({ queryKey: ['prod-cal'] });
      queryClient.invalidateQueries({ queryKey: ['calendario-dia'] });
      queryClient.invalidateQueries({ queryKey: ['pedidos'] });
      const msg = payload?.numero ? `Produção iniciada para: ${payload.numero}` : 'Produção iniciada!';
      toast.info(msg);
      addNotification({ title: 'Cozinha', message: msg, type: 'info' });
    };

    const handleProducaoConcluida = (payload: any) => {
      queryClient.invalidateQueries({ queryKey: ['pedidos'] });
      queryClient.invalidateQueries({ queryKey: ['producao'] });
      queryClient.invalidateQueries({ queryKey: ['production-orders'] });
      queryClient.invalidateQueries({ queryKey: ['prod-cal'] });
      queryClient.invalidateQueries({ queryKey: ['calendario-dia'] });
      queryClient.invalidateQueries({ queryKey: ['requests'] });
      const msg = payload?.numero ? `Ordem de produção concluída: ${payload.numero}` : 'Ordem de produção concluída!';
      toast.success(msg);
      addNotification({ title: 'Produção', message: msg, type: 'success' });
    };

    const handleAlertaStock = (payload: any) => {
      queryClient.invalidateQueries({ queryKey: ['produtos'] });
      queryClient.invalidateQueries({ queryKey: ['warehouse'] });
      const msg = payload?.msg && payload?.ingrediente 
        ? `Atenção: ${payload.msg} (Ingrediente: ${payload.ingrediente})`
        : payload?.msg || 'Alerta de stock mínimo atingido!';
      toast.error(msg);
      addNotification({ title: 'Stock Crítico', message: msg, type: 'error' });
    };

    const handlePedidoPronto = (payload: any) => {
      queryClient.invalidateQueries({ queryKey: ['pedidos'] });
      queryClient.invalidateQueries({ queryKey: ['producao'] });
      const clienteNome = payload?.cliente || 'Cliente';
      const orderNum = payload?.numero || payload?.id || '...';
      const msg = `Pedido ${orderNum} (${clienteNome}) pronto para entrega!`;
      toast.success(msg);
      addNotification({ title: 'Pedido Pronto', message: msg, type: 'success' });
    };

    const handlePedidoAtualizado = (payload: any) => {
      queryClient.invalidateQueries({ queryKey: ['pedidos'] });
      queryClient.invalidateQueries({ queryKey: ['producao'] });
      queryClient.invalidateQueries({ queryKey: ['entregas'] });
    };

    const handleLogisticaOcorrencia = (payload: any) => {
      queryClient.invalidateQueries({ queryKey: ['entregas'] });
      const msg = payload?.msg || 'Ocorrência registada na logística / transporte.';
      toast.warning(msg);
      addNotification({ title: 'Ocorrência Logística', message: msg, type: 'warning' });
    };

    const handleNovaRequisicao = (payload: any) => {
      queryClient.invalidateQueries({ queryKey: ['requests'] });
      const msg = payload?.codigo ? `Nova requisição de material criada: ${payload.codigo}` : 'Nova requisição de material recebida!';
      toast.info(msg);
      addNotification({ title: 'Armazém / Logística', message: msg, type: 'info' });
    };

    const handleNovoEvento = (payload: any) => {
      queryClient.invalidateQueries({ queryKey: ['events'] });
      queryClient.invalidateQueries({ queryKey: ['events-cal'] });
      queryClient.invalidateQueries({ queryKey: ['calendario-stats'] });
      queryClient.invalidateQueries({ queryKey: ['calendario-dia'] });
      const msg = payload?.titulo ? `Novo evento agendado: ${payload.titulo}` : 'Novo evento agendado!';
      toast.info(msg);
      addNotification({ title: 'Novo Evento', message: msg, type: 'info' });
    };

    on('novo_pedido', handleNovoPedido);
    on('novo_evento', handleNovoEvento);
    on('nova_ordem_producao', handleNovaOrdemProducao);
    on('producao_iniciada', handleProducaoIniciada);
    on('producao_concluida', handleProducaoConcluida);
    on('alerta_stock', handleAlertaStock);
    on('pedido_pronto', handlePedidoPronto);
    on('pedido_atualizado', handlePedidoAtualizado);
    on('logistica_ocorrencia', handleLogisticaOcorrencia);
    on('nova_requisicao', handleNovaRequisicao);

    return () => {
      off('novo_pedido', handleNovoPedido);
      off('novo_evento', handleNovoEvento);
      off('nova_ordem_producao', handleNovaOrdemProducao);
      off('producao_iniciada', handleProducaoIniciada);
      off('producao_concluida', handleProducaoConcluida);
      off('alerta_stock', handleAlertaStock);
      off('pedido_pronto', handlePedidoPronto);
      off('pedido_atualizado', handlePedidoAtualizado);
      off('logistica_ocorrencia', handleLogisticaOcorrencia);
      off('nova_requisicao', handleNovaRequisicao);
    };
  }, [on, off, queryClient, addNotification]);

  return null;
}
