import uuid
from datetime import datetime, timedelta
from app.models.ficha_tecnica import FichaTecnica, FichaTecnicaItem, TipoFicha
from app.models.ordem_producao import OrdemProducao, OrdemProducaoItem, SectorProducao, PrioridadeProducao, EstadoProducao, ConsumoIngrediente
from app.models.reserva import ReservaIngrediente, EstadoReserva
from app.models.pedido import Pedido, EstadoPedido
from app.models.item_pedido import ItemPedido, TipoItem
from app.models.produto import Produto
from app.models.ingrediente import Ingrediente
from app.models.receita import ReceitaProducao
from app.models.requisicao import Requisicao, RequisicaoItem, TipoRequisicao, EstadoRequisicao, TipoItemRequisicao
from app.models.turno import Turno
from app.models.movimento_stock import MovimentoStock, TipoMovimento, OrigemMovimento, EntidadeMovimento
from app.repositories.producao_repos import FichaTecnicaRepository, OrdemProducaoRepository
from app.services.audit_service import AuditService
from app.core.database import db
from app.websocket.socket_manager import socketio
from sqlalchemy import func

class ProducaoService:
    def __init__(self):
        self.ficha_repo = FichaTecnicaRepository()
        self.ordem_repo = OrdemProducaoRepository()

    @staticmethod
    def _turno_atual():
        """Devolve o turno ativo correspondente à hora atual, incluindo turnos noturnos."""
        agora = datetime.now().time()
        for turno in Turno.query.filter_by(ativo=True).all():
            if not turno.hora_inicio or not turno.hora_fim:
                continue
            if turno.hora_inicio <= turno.hora_fim:
                corresponde = turno.hora_inicio <= agora < turno.hora_fim
            else:
                corresponde = agora >= turno.hora_inicio or agora < turno.hora_fim
            if corresponde:
                return turno
        return None

    def _atualizar_requisicao_diaria(self, setor, necessidades, responsavel_id):
        """Agrupa consumíveis das OPs numa única requisição pendente por setor e turno."""
        if not necessidades or not responsavel_id:
            return
        turno = self._turno_atual()
        hoje = datetime.utcnow().date()
        req = Requisicao.query.filter(
            Requisicao.sector == setor.value,
            Requisicao.turno_id == (turno.id if turno else None),
            db.func.date(Requisicao.data_requisicao) == hoje,
            Requisicao.estado == EstadoRequisicao.PENDENTE.value,
        ).first()
        if not req:
            numero = f"REQ-{datetime.utcnow().strftime('%Y%m%d')}-{str(uuid.uuid4())[:6].upper()}"
            req = Requisicao(
                numero=numero, tipo=TipoRequisicao.INICIAL.value, sector=setor.value,
                turno_id=turno.id if turno else None, responsavel_id=responsavel_id,
                estado=EstadoRequisicao.PENDENTE.value,
                observacoes="Gerada automaticamente pelas ordens de produção do turno.",
            )
            db.session.add(req)
            db.session.flush()

        existentes = {item.item_id: item for item in req.itens if item.tipo_item == TipoItemRequisicao.CONSUMIVEL.value}
        for produto_id, quantidade in necessidades.items():
            item = existentes.get(produto_id)
            if item:
                item.quantidade_solicitada = float(item.quantidade_solicitada) + quantidade
            else:
                db.session.add(RequisicaoItem(
                    requisicao_id=req.id, tipo_item=TipoItemRequisicao.CONSUMIVEL.value,
                    item_id=produto_id, quantidade_solicitada=quantidade,
                    observacao="Calculado a partir das receitas dos produtos acabados.",
                ))

    # --- Fichas Técnicas ---
    def create_ficha(self, data, user_id):
        itens_data = data.pop('itens', [])
        ficha = FichaTecnica(**data, created_by=user_id)
        
        for item in itens_data:
            i = FichaTecnicaItem(
                ingrediente_id=item['ingrediente_id'],
                quantidade=item['quantidade'],
                unidade=item['unidade'],
                observacao=item.get('observacao')
            )
            ficha.itens.append(i)
            
        self.ficha_repo.create(ficha)
        AuditService.log_action(user_id, "CREATE", "fichas_tecnicas", ficha.id)
        return ficha, None

    # --- Criação Automática de Ordem ---
    def gerar_ordens_por_pedido(self, pedido_id, user_id=None):
        pedido = db.session.query(Pedido).filter_by(id=pedido_id).first()
        if not pedido: return False, "Pedido não encontrado"
        
        # Verificar se já existem ordens de produção para este pedido
        ordens_existentes = db.session.query(OrdemProducao).filter_by(pedido_id=pedido.id).all()
        if ordens_existentes:
            return True, None

        hoje = datetime.utcnow().date()
        producao_futura = bool(pedido.data_entrega and pedido.data_entrega > hoje)
        
        itens_por_setor = {
            SectorProducao.COZINHA: [],
            SectorProducao.PASTELARIA: [],
            SectorProducao.BAR: []
        }
        ordens_criadas = []
        
        for item in pedido.itens:
            if not item.produto_id:
                continue

            produto = db.session.query(Produto).filter_by(id=item.produto_id).first()
            if not produto:
                continue

            setor = None
            if produto.servico:
                servico_str = produto.servico.value if hasattr(produto.servico, 'value') else str(produto.servico)
                if servico_str == 'COZINHA':
                    setor = SectorProducao.COZINHA
                elif servico_str == 'PASTELARIA':
                    setor = SectorProducao.PASTELARIA
                elif servico_str == 'BAR':
                    setor = SectorProducao.BAR
            
            receita = db.session.query(ReceitaProducao).filter_by(produto_acabado_id=item.produto_id, ativo=True).first()
            if not setor and receita and receita.setor:
                setor = next((s for s in SectorProducao if s.value == receita.setor), None)

            if not setor:
                ficha = db.session.query(FichaTecnica).filter_by(produto_acabado_id=item.produto_id, ativo=True).first()
                if ficha:
                    setor = SectorProducao.COZINHA if (ficha.tipo.value if hasattr(ficha.tipo, 'value') else str(ficha.tipo)) == TipoFicha.COZINHA.value else SectorProducao.PASTELARIA
                else:
                    cat_or_name = f"{produto.categoria or ''} {produto.nome or ''}".lower()
                    pastelaria_keywords = ['bolo', 'doce', 'pastel', 'pão', 'pao', 'tarte', 'croissant', 'queque', 'pastelaria', 'sobremesa', 'mousse', 'torta']
                    bar_keywords = ['bebida', 'sumo', 'cerveja', 'água', 'agua', 'refrigerante', 'café', 'cafe', 'chá', 'cha', 'cocktail', 'licor', 'vinho']
                    if any(kw in cat_or_name for kw in bar_keywords):
                        setor = SectorProducao.BAR
                    elif any(kw in cat_or_name for kw in pastelaria_keywords):
                        setor = SectorProducao.PASTELARIA
                    else:
                        setor = SectorProducao.COZINHA
            else:
                ficha = db.session.query(FichaTecnica).filter_by(produto_acabado_id=item.produto_id, ativo=True).first()
            
            if setor in itens_por_setor:
                itens_por_setor[setor].append((item, ficha, receita))
            
        for setor, items in itens_por_setor.items():
            if not items:
                continue
                
            numero = f"OP-{setor.value[:3].upper()}-{datetime.utcnow().strftime('%Y%m')}-{str(uuid.uuid4())[:6].upper()}"
            ordem = OrdemProducao(
                numero=numero,
                pedido_id=pedido.id,
                sector=setor,
                prioridade=PrioridadeProducao.MEDIA,
                data_producao=pedido.data_entrega if producao_futura else hoje,
                estado=EstadoProducao.PENDENTE if producao_futura else EstadoProducao.EM_PRODUCAO,
                created_by=user_id
            )
            if not producao_futura:
                ordem.hora_inicio = datetime.utcnow()

            db.session.add(ordem)
            db.session.flush() # Para gerar o ID da ordem
            ordens_criadas.append(ordem)
            
            necessidades_consumiveis = {}
            for item, ficha, receita in items:
                op_item = OrdemProducaoItem(
                    ordem_producao_id=ordem.id,
                    produto_id=item.produto_id,
                    quantidade=item.quantidade,
                    observacoes=getattr(item, 'observacoes', None)
                )
                db.session.add(op_item)
                
                if ficha:
                    for req in ficha.itens:
                        qtd_total_prevista = float(req.quantidade) * float(item.quantidade)
                        
                        consumo = ConsumoIngrediente(
                            ordem_producao_id=ordem.id,
                            ingrediente_id=req.ingrediente_id,
                            quantidade_prevista=qtd_total_prevista
                        )
                        db.session.add(consumo)
                        
                        if producao_futura:
                            reserva = ReservaIngrediente(
                                ingrediente_id=req.ingrediente_id,
                                pedido_id=pedido.id,
                                quantidade=qtd_total_prevista
                            )
                            db.session.add(reserva)

                if receita:
                    for receita_item in receita.itens:
                        qtd_total_prevista = float(receita_item.quantidade) * float(item.quantidade)
                        db.session.add(ConsumoIngrediente(
                            ordem_producao_id=ordem.id,
                            produto_consumivel_id=receita_item.produto_consumivel_id,
                            quantidade_prevista=qtd_total_prevista,
                        ))
                        necessidades_consumiveis[receita_item.produto_consumivel_id] = (
                            necessidades_consumiveis.get(receita_item.produto_consumivel_id, 0) + qtd_total_prevista
                        )

            self._atualizar_requisicao_diaria(setor, necessidades_consumiveis, user_id or pedido.created_by)
        
        db.session.commit()
        # Orders created for an immediate pedido start in production. Keep the
        # pedido list in the same operational state; payment is tracked
        # separately in `estado_pagamento`.
        if ordens_criadas and not producao_futura:
            estado_anterior = pedido.estado.value if hasattr(pedido.estado, 'value') else str(pedido.estado)
            pedido.estado = EstadoPedido.EM_PRODUCAO.value
            db.session.commit()
            socketio.emit('pedido_atualizado', {
                'numero': pedido.numero,
                'antigo_estado': estado_anterior,
                'novo_estado': EstadoPedido.EM_PRODUCAO.value,
            })
        for ordem in ordens_criadas:
            if user_id:
                AuditService.log_action(user_id, "CREATE", "ordens_producao", ordem.id)
            
        from app.websocket.socket_manager import notify_production_orders
        notify_production_orders(pedido.id, pedido.numero, [ordem.sector for ordem in ordens_criadas])
        return True, None

    # --- Processamento Automático de Pedidos Agendados ---
    def processar_pedidos_agendados(self):
        """
        Verifica pedidos agendados para a data atual (ou anteriores) e os coloca
        automaticamente em produção, notificando o pessoal da cozinha e pastelaria.
        """
        hoje = datetime.utcnow().date()
        
        pedidos_agendados = db.session.query(Pedido).filter(
            Pedido.estado.in_([
                EstadoPedido.AGENDADO.value, EstadoPedido.AGENDADO,
                EstadoPedido.CONFIRMADO.value, EstadoPedido.CONFIRMADO,
                EstadoPedido.PENDENTE.value, EstadoPedido.PENDENTE
            ]),
            (Pedido.data_entrega <= hoje) | (Pedido.data_entrega.is_(None))
        ).all()
        
        processados = []
        for pedido in pedidos_agendados:
            estado_str = pedido.estado.value if hasattr(pedido.estado, 'value') else str(pedido.estado)
            # Se estiver Pendente e sem data de entrega definida nem sinal pago, ignora
            if estado_str in ['Pendente', 'PENDENTE'] and not (pedido.valor_pago and float(pedido.valor_pago) > 0) and pedido.data_entrega != hoje:
                continue

            ordens_existentes = db.session.query(OrdemProducao).filter_by(pedido_id=pedido.id).all()
            if not ordens_existentes:
                self.gerar_ordens_por_pedido(pedido.id)
                ordens_existentes = db.session.query(OrdemProducao).filter_by(pedido_id=pedido.id).all()

            if estado_str in ['Agendado', 'AGENDADO', 'Confirmado', 'CONFIRMADO', 'Pendente', 'PENDENTE']:
                pedido.estado = EstadoPedido.EM_PRODUCAO
            
            for ordem in ordens_existentes:
                ordem_est = ordem.estado.value if hasattr(ordem.estado, 'value') else str(ordem.estado)
                if ordem_est in ['Pendente', 'PENDENTE']:
                    ordem.estado = EstadoProducao.EM_PRODUCAO
                    if not ordem.hora_inicio:
                        ordem.hora_inicio = datetime.utcnow()
            
            processados.append(pedido)

        if processados:
            db.session.commit()
            for p in processados:
                socketio.emit('pedido_atualizado', {
                    'numero': p.numero,
                    'antigo_estado': 'Agendado',
                    'novo_estado': EstadoPedido.EM_PRODUCAO.value
                })
                socketio.emit('nova_ordem_producao', {'pedido_id': p.id, 'numero': p.numero})
                socketio.emit('alerta_producao', {
                    'msg': f'O Pedido #{p.numero} agendado para hoje entrou automaticamente em produção!'
                })

        return len(processados)

    # --- Controle de Ordem ---
    def alterar_estado_ordem(self, ordem_id, estado_novo, user_id):
        ordem = self.ordem_repo.get_by_id(ordem_id)
        if not ordem: return None, "Ordem não encontrada"
        
        estado_antigo = ordem.estado
        ordem.estado = estado_novo
        
        estado_novo_str = estado_novo.value if hasattr(estado_novo, 'value') else str(estado_novo)

        if estado_novo_str in [EstadoProducao.EM_PRODUCAO.value, 'Em Producao', 'EM_PRODUCAO']:
            ordem.hora_inicio = datetime.utcnow()
            
            # Atualizar estado do Pedido associado se necessário
            if ordem.pedido_id:
                pedido = db.session.query(Pedido).get(ordem.pedido_id)
                if pedido:
                    ped_est = pedido.estado.value if hasattr(pedido.estado, 'value') else str(pedido.estado)
                    if ped_est in ['Pendente', 'PENDENTE', 'Agendado', 'AGENDADO', 'Confirmado', 'CONFIRMADO']:
                        pedido.estado = EstadoPedido.EM_PRODUCAO.value if hasattr(EstadoPedido.EM_PRODUCAO, 'value') else 'Em Producao'
                        socketio.emit('pedido_atualizado', {
                            'numero': pedido.numero,
                            'antigo_estado': ped_est,
                            'novo_estado': 'Em Producao'
                        })

            socketio.emit('producao_iniciada', {'ordem_numero': ordem.numero})
            
        elif estado_novo_str in [EstadoProducao.PRONTO.value, 'Pronto', 'PRONTO']:
            ordem.hora_fim = datetime.utcnow()
            
            # Consumir ingredientes na ordem (stock é descontado via Entrega de Requisição no armazém)
            for consumo in ordem.consumos:
                consumo.quantidade_consumida = consumo.quantidade_prevista
                consumo.data_consumo = datetime.utcnow()
                
            # Check if reservations exist for this, mark utilized
            reservas = db.session.query(ReservaIngrediente).filter_by(pedido_id=ordem.pedido_id, estado=EstadoReserva.ATIVA.value).all()
            for r in reservas:
                r.estado = EstadoReserva.UTILIZADA.value

            # Atualizar estado do Pedido se TODAS as Ordens de Produção do Pedido estiverem PRONTO
            if ordem.pedido_id:
                todas_ordens = db.session.query(OrdemProducao).filter_by(pedido_id=ordem.pedido_id).all()
                todas_prontas = True
                for o in todas_ordens:
                    o_est = o.estado.value if hasattr(o.estado, 'value') else str(o.estado)
                    if o.id == ordem.id:
                        o_est = 'Pronto'
                    if o_est not in ['Pronto', 'PRONTO', 'Concluido', 'CONCLUIDO', 'Cancelado', 'CANCELADO']:
                        todas_prontas = False
                        break
                
                if todas_prontas:
                    pedido = db.session.query(Pedido).get(ordem.pedido_id)
                    if pedido:
                        ped_est = pedido.estado.value if hasattr(pedido.estado, 'value') else str(pedido.estado)
                        if ped_est != 'Pronto':
                            pedido.estado = EstadoPedido.PRONTO.value if hasattr(EstadoPedido.PRONTO, 'value') else 'Pronto'
                            socketio.emit('pedido_atualizado', {
                                'numero': pedido.numero,
                                'antigo_estado': ped_est,
                                'novo_estado': 'Pronto'
                            })
            
            socketio.emit('producao_concluida', {'ordem_numero': ordem.numero})
            
        db.session.commit()
        AuditService.log_action(user_id, "UPDATE_ESTADO_OP", "ordens_producao", ordem.id)
        return ordem, None

    def update_ordem(self, ordem_id, data, user_id):
        ordem = self.ordem_repo.get_by_id(ordem_id)
        if not ordem: return None, "Ordem não encontrada"
        
        if 'turno' in data:
            ordem.turno = data['turno']
            
        if 'data_producao' in data:
            ordem.data_producao = data['data_producao']

        db.session.commit()
        AuditService.log_action(user_id, "UPDATE_OP", "ordens_producao", ordem.id)
        return ordem, None

    # --- Planeamento ---
    def prever_consumo(self, dias=7):
        hoje = datetime.utcnow().date()
        data_limite = hoje + timedelta(days=dias)
        
        consumos = db.session.query(
            ConsumoIngrediente.ingrediente_id,
            Ingrediente.nome,
            func.sum(ConsumoIngrediente.quantidade_prevista).label('total_previsto')
        ).join(OrdemProducao).join(Ingrediente).filter(
            OrdemProducao.data_producao >= hoje,
            OrdemProducao.data_producao <= data_limite,
            OrdemProducao.estado.in_([EstadoProducao.PENDENTE.value, EstadoProducao.EM_PRODUCAO.value])
        ).group_by(ConsumoIngrediente.ingrediente_id, Ingrediente.nome).all()
        
        return [{"ingrediente_id": c[0], "nome": c[1], "quantidade_necessaria": float(c[2])} for c in consumos]
